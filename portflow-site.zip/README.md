# PORTFLOW 배포 패키지 (v2.3)

이 폴더를 그대로 올리면 됩니다. 서버 코드 없음, 정적 파일 4개 + 아이콘.

## 방법 A — GitHub Pages (무료, 추천)
1. github.com 로그인 → New repository → 이름 `portflow` → Public → Create.
2. "uploading an existing file" 클릭 → 이 폴더 안의 파일 전부(index.html, manifest.json, sw.js, icon-192.png, icon-512.png) 드래그 → Commit.
3. Settings → Pages → Branch: `main`, folder `/ (root)` → Save.
   1~2분 뒤 `https://<아이디>.github.io/portflow/` 에서 열립니다.

## 방법 B — Netlify Drop (가입 필요, 1분)
app.netlify.com/drop 에 이 폴더를 드래그 → 바로 주소가 나옵니다.

## 아이패드/폰에서 앱처럼
Safari로 주소 열기 → 공유 → "홈 화면에 추가". 전체화면 + 오프라인 동작.
(3D는 three.js를 cdnjs에서 받으므로 첫 실행은 온라인이어야 합니다.)

## 주의
- 모든 전력·요금 수치는 가상/가정값입니다. 페이지 안 표시 그대로입니다.
- 수정하려면 index.html 하나만 고치면 됩니다. 수정 후 sw.js의 `portflow-v23`을 `v24`로 올리면 캐시가 갱신됩니다.
